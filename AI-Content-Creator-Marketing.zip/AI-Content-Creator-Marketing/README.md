# AI Content Creator Marketing

A responsive, GitHub Pages-ready frontend prototype for an AI content creator marketplace.

## Features
- Creator discovery with keyword, category, platform, content-style, and budget filters
- Creator profile modal with niche, portfolio themes, rating, and estimated pricing
- Campaign creation form with validation
- AI content studio demo that creates hooks, content drafts, creative direction, and CTAs from local templates
- Copy and save generated drafts
- Campaign dashboard with View, status update, search, and delete
- LocalStorage persistence for campaigns and draft count
- Responsive desktop, tablet, and mobile layouts

## Run locally
Open `index.html` in your browser, or use VS Code Live Server.

## Publish using GitHub Pages
1. Create a new public GitHub repository, for example `ai-content-creator-marketing`.
2. Extract this folder on your computer.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root (not inside an extra nested folder).
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes; GitHub will show the published website URL in the Pages section.

## Important prototype note
The content studio uses local templates and is not connected to a real AI service. To use a live AI model, create a backend/serverless function and keep the API key on the server. Never put a secret API key inside `script.js` or any frontend file.

Campaigns are saved in the browser's LocalStorage, so they stay on the same browser/device and are not synced between users.
